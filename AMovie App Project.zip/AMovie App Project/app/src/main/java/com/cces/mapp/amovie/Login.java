package com.cces.mapp.amovie;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity implements View.OnClickListener {
    private TextView register;
    private EditText editEmail, editPass;
    private FirebaseAuth mAuth;
    private ProgressBar progressBar;
    private Button sigIn;
    private TextView fpassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        fpassword = (TextView) findViewById(R.id.fpassword);
        register = (TextView) findViewById(R.id.register);
        register.setOnClickListener(this);
        fpassword.setOnClickListener(this);
        editEmail = (EditText)findViewById(R.id.username);
        editPass = (EditText)findViewById(R.id.pass);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        sigIn = (Button) findViewById(R.id.sigIn);
        sigIn.setOnClickListener(this);
        mAuth = FirebaseAuth.getInstance();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.register:
                startActivity(new Intent(this, Register.class));
                break;
            case R.id.sigIn:
                userLoginIn();
                break;
            case R.id.fpassword:
                startActivity(new Intent(this, ForgetPassword.class));

                 break;
            default:
                break;
        }
    }

    private void userLoginIn() {
        String m = editEmail.getText().toString().trim();
        String p = editPass.getText().toString().trim();
        if(m.isEmpty())
        {
            editEmail.setError("Email is required");
            editEmail.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(m).matches()) {
            editEmail.setError("Please provide valid email");
            editEmail.requestFocus();
            return;
        }
        if(p.isEmpty())
        {
            editPass.setError("Email is required");
            editPass.requestFocus();
            return;
        }
        if(p.length()<8){
            editPass.setError("Password must be of 8 or more characters");
            editPass.requestFocus();
            return;
        }
        progressBar.setVisibility(View.VISIBLE);
        mAuth.signInWithEmailAndPassword(m,p).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    startActivity(new Intent(Login.this,MainActivity.class));
                }else{
                    Toast.makeText(Login.this,"Failed to login",Toast.LENGTH_LONG).show();
                }

            }
        });
    }
}
