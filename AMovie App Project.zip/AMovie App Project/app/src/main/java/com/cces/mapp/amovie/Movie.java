package com.cces.mapp.amovie;

public class Movie {
    private int id;
    private String name;
    private String director;
    private String imageURL;
    private String description;

    public Movie(int id, String name, String author, String imageURL, String description) {
        this.id = id;
        this.name = name;
        this.director = author;
        this.imageURL = imageURL;
        this.description = description;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
