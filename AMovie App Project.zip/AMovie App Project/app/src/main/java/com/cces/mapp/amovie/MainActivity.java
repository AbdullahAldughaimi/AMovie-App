package com.cces.mapp.amovie;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    Button btnAllMovies, btnFavorite, btnAlready, btnIMDb, btnAbout;
    Button logout;
    FirebaseAuth mAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initWidget();
        setOnclickListener();
        logout = (Button) findViewById(R.id.signOut);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mAuth.signOut();
                startActivity(new Intent(MainActivity.this, Login.class));
            }
        });
    }
    private void setOnclickListener() {
        btnAllMovies.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(MainActivity.this, ShowAll.class);
                startActivity(in);
            }
        });
        btnFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(MainActivity.this, Favorite.class);
                startActivity(in);
            }
        });
        btnAlready.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(MainActivity.this, Already.class);
                startActivity(in);
            }
        });
        btnIMDb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(MainActivity.this, IMDb.class);
                in.putExtra("loadurl","https://www.imdb.com/chart/top/");
                startActivity(in);
            }
        });
        btnAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(MainActivity.this, About.class);
                startActivity(in);
            }
        });
    }


    private void initWidget()
    {
        btnAllMovies = (Button) findViewById(R.id.btnAllMovies);
        btnFavorite = (Button) findViewById(R.id.btnFavorite);
        btnAlready = (Button) findViewById(R.id.btnAlready);
        btnIMDb = (Button) findViewById(R.id.btnIMDb);
        btnAbout = (Button) findViewById(R.id.btnAbout);

    }



}
