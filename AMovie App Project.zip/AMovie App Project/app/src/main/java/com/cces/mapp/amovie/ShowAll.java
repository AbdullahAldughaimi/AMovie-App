package com.cces.mapp.amovie;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;

import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class ShowAll extends AppCompatActivity {
    RecyclerView moviesRecView;
    MovieRecViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        moviesRecView = (RecyclerView) findViewById(R.id.moviesRecViewList);
         adapter = new MovieRecViewAdapter(this,"ShowAll");
        moviesRecView.setAdapter(adapter);
        moviesRecView.setLayoutManager(new GridLayoutManager(this, 2));
        ArrayList<Movie> movie = new ArrayList<>();
        Util util = new Util();
        movie = util.getShowAllMovie();
        adapter.setMovies(movie);

    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case android.R.id.home:
                super.onBackPressed();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.searchmenu,menu);
        MenuItem item=menu.findItem(R.id.search);
        SearchView searchView=(SearchView)item.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                adapter.getFilter().filter(s);
                return false;
            }
        });        return super.onCreateOptionsMenu(menu);
    }

}