package com.cces.mapp.amovie;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class IMDb extends AppCompatActivity {
    private WebView IMDbWebView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_i_m_db);
        String url = getIntent().getStringExtra("loadurl");
        IMDbWebView = (WebView) findViewById(R.id.IMDbWebView);
        IMDbWebView.setWebViewClient(new WebViewClient());
        IMDbWebView.getSettings().setJavaScriptEnabled(true);
        IMDbWebView.loadUrl(url);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case android.R.id.home:
                super.onBackPressed();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}