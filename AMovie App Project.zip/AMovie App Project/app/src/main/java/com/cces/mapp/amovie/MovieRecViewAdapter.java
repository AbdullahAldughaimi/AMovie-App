package com.cces.mapp.amovie;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class MovieRecViewAdapter  extends RecyclerView.Adapter<MovieRecViewAdapter.ViewHolder> implements Filterable {

    ArrayList<Movie> movies = new ArrayList<Movie>();
    private Util util;
    Context context;
    private String actName = "";
    ArrayList<Movie> MoviesAll;


    public void setMovies(ArrayList<Movie> movies) {
        this.movies = movies;
        MoviesAll = new ArrayList<>(movies);
        notifyDataSetChanged();
    }

    public MovieRecViewAdapter(Context context, String actName) {
        this.context = context;
        this.actName = actName;
        util = new Util();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_movie, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        Movie movie = movies.get(position);
        holder.movieName.setText(movies.get(position).getName());
        holder.movieCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(context, MovieActivity.class);
                in.putExtra("movieId", movies.get(position).getId());
                context.startActivity(in);
            }
        });
        holder.movieCardView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                switch (actName) {

                    case "Favorite":
                        if (util.removeFavorite(movies.get(position))) {

                            Toast.makeText(context, movie.getName() + " is deleted from favorite movies list.", Toast.LENGTH_SHORT).show();
                            notifyDataSetChanged();

                        }

                        break;

                    case "Already":
                        if (util.removeAlreadyWatched(movies.get(position))) {
                            Toast.makeText(context, movie.getName() + " is deleted from watched list.", Toast.LENGTH_SHORT).show();
                            notifyDataSetChanged();

                        }
                        break;
                    default:
                        break;
                }
                return false;
            }
        });

        Glide.with(context).asBitmap().load(movies.get(position).getImageURL()).into(holder.movieImage);
    }

    @Override
    public int getItemCount() {
        return movies.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView movieImage;
        private TextView movieName;
        private CardView movieCardView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            movieImage = (ImageView) itemView.findViewById(R.id.movieImage);
            movieName = (TextView) itemView.findViewById(R.id.movieName);
            movieCardView = (CardView) itemView.findViewById(R.id.movieCardView);
        }
    }

    @Override
    public Filter getFilter() {
        return filter;
    }

    Filter filter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            ArrayList<Movie> MoviesFiltered = new ArrayList<Movie>();
          if (constraint ==null || constraint.length()==0){

              MoviesFiltered.addAll(MoviesAll);

          }else{
              String fillterpattern = constraint.toString().toLowerCase();
                      for (Movie item :  MoviesAll){
                          if(item.getName().toLowerCase().startsWith(fillterpattern)){
                              MoviesFiltered.add(item);
                          }
                      }
          }
            FilterResults results = new FilterResults();
          results.values = MoviesFiltered;
          return  results;

        }


        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {

            movies.clear();
            movies.addAll((ArrayList) results.values);
            notifyDataSetChanged();
        }

    };

}


