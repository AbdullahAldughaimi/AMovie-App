package com.cces.mapp.amovie;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class ForgetPassword extends AppCompatActivity implements View.OnClickListener {
    private FirebaseAuth mAuth;
    private EditText mail;
    private Button btnsend;
    private ProgressBar progressBar;
    String email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
        mAuth = FirebaseAuth.getInstance();
        mail = (EditText) findViewById(R.id.mail);
        btnsend = (Button) findViewById(R.id.btnsend);

        btnsend.setOnClickListener(this);
        progressBar = (ProgressBar) findViewById(R.id.progressBar2);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case android.R.id.home:
                super.onBackPressed();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.btnsend:
                FirebaseAuth.getInstance().sendPasswordResetEmail(mail.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(ForgetPassword.this,"Email sent.",Toast.LENGTH_LONG).show();

                                }else if (!task.isSuccessful()){
                                    Toast.makeText(ForgetPassword.this,"Email does not exist.",Toast.LENGTH_LONG).show();
                                }
                            }
                        });
                break;
            default:
                break;
        }
    }
    public void onComplete(@NonNull Task<AuthResult> task) {
        if(task.isSuccessful()){
            startActivity(new Intent(ForgetPassword.this,MainActivity.class));
        }else{
            Toast.makeText(ForgetPassword.this,"Email does not exist.",Toast.LENGTH_LONG).show();
        }

    }
}