package com.cces.mapp.amovie;

import java.util.ArrayList;

public class Util {
    private static ArrayList<Movie> ShowAllMovie;
    private static ArrayList<Movie> Favorite;
    private static ArrayList<Movie> AlreadyWatched;

    private int id = 0;

    public Util() {
        if(ShowAllMovie == null){
            ShowAllMovie = new ArrayList<>();
            initShowAllMovie();
        }
        if(Favorite == null){
            Favorite = new ArrayList<>();
        }

        if(AlreadyWatched == null){
            AlreadyWatched = new ArrayList<>();
        }

    }

    public static ArrayList<Movie> getShowAllMovie() {
        return ShowAllMovie;
    }

    public static ArrayList<Movie> getFavorite() {
        return Favorite;
    }


    public static ArrayList<Movie> getAlreadyWatched() {
        return AlreadyWatched;
    }


    public boolean addFavorite(Movie b)
    {
        return Favorite.add(b);
    }
    public boolean addAlreadyWatched(Movie b) { return AlreadyWatched.add(b); }


    public boolean removeFavorite(Movie b)
    {
        return Favorite.remove(b);
    }
    public boolean removeAlreadyWatched(Movie b)
    {
        return AlreadyWatched.remove(b);
    }

    private void initShowAllMovie()
    {
        String name="", Director="", imageUrl="", description="";
        id++;
        name = "The Shawshank Redemption"; Director="Frank Darabont"; description="Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.";
        imageUrl="https://m.media-amazon.com/images/M/MV5BMDFkYTc0MGEtZmNhMC00ZDIzLWFmNTEtODM1ZmRlYWMwMWFmXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_UY1200_CR89,0,630,1200_AL_.jpg";
        ShowAllMovie.add(new Movie(id,name,Director,imageUrl,description));

        id++;
        name = "The Dark Knight "; Director="Christopher Nolan"; description="When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.";
        imageUrl="https://soundvapors.com/wp-content/uploads/2020/06/tdk-1024x1024.jpg";
        ShowAllMovie.add(new Movie(id,name,Director,imageUrl,description));


        id++;
        name = "Godzilla vs. Kong "; Director="Adam Wingard"; description="The epic next chapter in the cinematic Monsterverse pits two of the greatest icons in motion picture history against one another - the fearsome Godzilla and the mighty Kong - with humanity caught in the balance.";
        imageUrl="https://i.ytimg.com/vi/sWQbrM3xZ1E/maxresdefault.jpg";
        ShowAllMovie.add(new Movie(id,name,Director,imageUrl,description));

        id++;
        name = "Wrath of Man  "; Director="Guy Ritchie"; description="The plot follows H, a cold and mysterious character working at a cash truck company responsible for moving hundreds of millions of dollars around Los Angeles each week.";
        imageUrl="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRNbbzciA3fAjddgUpujUJp4xyM7nVdGO8t8JS0GLjISVCr0siL";
        ShowAllMovie.add(new Movie(id,name,Director,imageUrl,description));

        id++;
        name = "The Occupant"; Director="David Pastor, Àlex Pastor"; description="Javier Muñoz, once a successful executive, makes the fateful decision to leave his home, which him and his family can no longer afford.";
        imageUrl="https://upload.wikimedia.org/wikipedia/en/d/d1/The_Occupant_poster.jpg";
        ShowAllMovie.add(new Movie(id,name,Director,imageUrl,description));

        id++;
        name = "The Beast"; Director="Ludovico Di Martino"; description="Leonida Riva is a solitary war veteran who has spent years away from his family. When his daughter,Teresa, is kidnapped, he rediscovers the anger and ferocity he thought he had buried in the past.";
        imageUrl="https://m.media-amazon.com/images/M/MV5BZDA3MGJlYjItYmMzOC00MGU4LTgzNjEtMjcyOTJkNmNiZmE5XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_.jpg";
        ShowAllMovie.add(new Movie(id,name,Director,imageUrl,description));



        id++;
        name = "Nobody"; Director="Ilya Naishuller"; description="Hutch Mansell fails to defend himself or his family when two thieves break into his suburban home one night. The aftermath of the incident soon strikes a match to his long-simmering rage. In a barrage of fists, gunfire and squealing tires, Hutch must now save his wife and son from a dangerous adversary -- and ensure that he will never be underestimated again.\n";
        imageUrl="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcSk8R-kZgYqHLrjWXS-dPQmtU8J4EguMVIurJeCF92DKTjyR4Z9";
        ShowAllMovie.add(new Movie(id,name,Director,imageUrl,description));



        id++;
        name = "Earth and Blood"; Director="Julien Leclercq"; description="A man who runs a sawmill in Belgium receives an unwelcome visit from a cartel.";
        imageUrl="https://upload.wikimedia.org/wikipedia/en/0/09/Earth_and_Blood_poster.jpg";
        ShowAllMovie.add(new Movie(id,name,Director,imageUrl,description));

        id++;
        name = "Mortal Kombat"; Director="Simon McQuoid"; description="Mortal Kombat is a mysterious, intergalactic tournament of ancient martial arts. Shaolin Monk Liu Kang, from Earth, gets invited as a competitor.";
        imageUrl="https://upload.wikimedia.org/wikipedia/ar/3/37/Mortal_Kombat_%282021_film%29.png";
        ShowAllMovie.add(new Movie(id,name,Director,imageUrl,description));


        id++;
        name = "Rising High"; Director="Cüneyt Kaya"; description="Charting the rise and fall of three corrupt real estate agents who accumulate absurd wealth in no time but fall into a vortex of fraud, greed and drugs.";
        imageUrl="https://m.media-amazon.com/images/M/MV5BYTVjNDE3NjktYmMyNC00MTRmLTlmZWItMzk3NzViY2Y4MmFhXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_.jpg";
        ShowAllMovie.add(new Movie(id,name,Director,imageUrl,description));
    }

}
