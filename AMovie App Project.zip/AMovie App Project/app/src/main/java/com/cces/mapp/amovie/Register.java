package com.cces.mapp.amovie;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity implements View.OnClickListener {
    private FirebaseAuth mAuth;
    private EditText fname, age, mail, pwd,cpwd;
    private Button btnRegister;
    private ProgressBar progressBar;
    String name, ag,email,password, confirmPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mAuth = FirebaseAuth.getInstance();
        fname = (EditText) findViewById(R.id.fname);
        age = (EditText) findViewById(R.id.age);
        mail = (EditText) findViewById(R.id.mail);
        pwd = (EditText) findViewById(R.id.pwd);
        cpwd = (EditText) findViewById(R.id.cpwd);

        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);
        progressBar = (ProgressBar) findViewById(R.id.progressBar2);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case android.R.id.home:
                super.onBackPressed();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.btnRegister:
                RegisterUser();
                break;
        }
    }

    private void RegisterUser() {
        name = fname.getText().toString().trim();
        ag = age.getText().toString().trim();
        email = mail.getText().toString().trim();
        password = pwd.getText().toString().trim();
        confirmPassword = cpwd.getText().toString().trim();

        if(name.isEmpty()){
            fname.setError("Full names is required");
            fname.requestFocus();
            return;
        }
        if(ag.isEmpty()){
            age.setError("Age is required");
            age.requestFocus();
            return;
        }
        if(email.isEmpty()){
            mail.setError("Email is required");
            mail.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            mail.setError("Please provide valid email");
            mail.requestFocus();
            return;
        }
        if(password.isEmpty()){
            pwd.setError("Password is required");
            pwd.requestFocus();
            return;
        }
        if(password.isEmpty()){
            cpwd.setError("Confirm Password is required");
            cpwd.requestFocus();
            return;
        }
        if(password.length()<8){
            pwd.setError("Password must be of 8 or more characters");
            pwd.requestFocus();
            return;
        }
        if(!password.equals(confirmPassword) ){
            cpwd.setError("Password does not matched");
            cpwd.requestFocus();
            return;
        }
        progressBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(email,password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            User user = new User(name, ag, email);
                            FirebaseDatabase.getInstance().getReference("Movie")
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful()){
                                        Toast.makeText(Register.this, "User has been registered Successfully",Toast.LENGTH_LONG).show();
                                        progressBar.setVisibility(View.GONE);
                                    }else{
                                        Toast.makeText(Register.this, "Failed to register",Toast.LENGTH_LONG).show();
                                        progressBar.setVisibility(View.GONE);
                                    }
                                }
                            });
                        }else{
                            Toast.makeText(Register.this, "Failed to register",Toast.LENGTH_LONG).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });
    }
}
