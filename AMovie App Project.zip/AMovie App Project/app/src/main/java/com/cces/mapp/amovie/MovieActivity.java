package com.cces.mapp.amovie;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class MovieActivity extends AppCompatActivity  {
    TextView MovieName, director, description;
    ImageView movieImage;
    Button btnFavorite, btnAlready;
    private Movie incomingMovie;
    private Util util;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initWidget();
        Intent in = getIntent();
        int id = in.getIntExtra("movieId",0);
        util = new Util();
        ArrayList<Movie> movies = util.getShowAllMovie();

        for(Movie b: movies)
        {
            if(b.getId() == id){
                incomingMovie = b;
                MovieName.setText(b.getName());
                director.setText(b.getDirector());
                description.setText(b.getDescription());
                Glide.with(this).asBitmap().load(b.getImageURL()).into(movieImage);
            }
        }
        btnFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnFavoriteTapped();
            }
        });

        btnAlready.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnAlreadyTapped();
            }
        });
    }
    private void btnFavoriteTapped(){
        boolean doesExist = false;
        ArrayList<Movie> getFavorite = util.getFavorite();
        for(Movie b: getFavorite)
        {
            if(b.getId()== incomingMovie.getId())
                doesExist = true;
        }
        if(doesExist)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("You already added this movie to your favorite list");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            builder.setCancelable(false);
            builder.create().show();
        }else{
            util.addFavorite(incomingMovie);
            Toast.makeText(this,"The Movie "+incomingMovie.getName()+" added to your favorite list", Toast.LENGTH_SHORT).show();
        }
    }
    private void btnAlreadyTapped(){
        boolean doesExist = false;
        ArrayList<Movie> getAlreadyWatched = util.getAlreadyWatched();
        for(Movie b: getAlreadyWatched)
        {
            if(b.getId()== incomingMovie.getId())
                doesExist = true;
        }
        if(doesExist)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("You already added this movie to your watched list");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            builder.setCancelable(false);
            builder.create().show();
        }else{
            util.addAlreadyWatched(incomingMovie);
            Toast.makeText(this,"The Movie "+incomingMovie.getName()+" added to your already watched list", Toast.LENGTH_SHORT).show();
        }
    }

    private void initWidget(){
        MovieName = (TextView) findViewById(R.id.movieName);
        director = (TextView) findViewById(R.id.DirectorName);
        description = (TextView) findViewById(R.id.movieDesc);
        movieImage = (ImageView) findViewById(R.id.movieImage);
        btnFavorite = (Button) findViewById(R.id.btnFavorite);
        btnAlready = (Button) findViewById(R.id.btnAlready);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case android.R.id.home:
                super.onBackPressed();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
